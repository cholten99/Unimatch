<?php
	echo("Hello, World!");
?>