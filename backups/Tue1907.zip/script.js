/* Universities jQuery */

// When the search box gets clicked
function show_search_box() { 
	$("#search-box").show();	
	$("#results-box").hide();	
}
// When the sort box gets clicked
function show_sort_box() { 
	$("#results-box").show();	
	$("#search-box").hide();
}
function do_go() {
	show_sort_box();
	myParser.parse('places.php');
	
	//map.getMarkerById(5).visible = false;
	//map.setZoom(100);
	google.maps.event.trigger(allmarkers[0], 'click');
	
	/*$.ajax({
	        url: './places.php',
	        method: 'GET',
	        data: { fred: "addr" },
	        error: function(response) { alert(response); },
	        success: function(response) { alert(response); }
    	});*/	
}

// When the page loads
$(function() {
	// Load the boxes

	$("#results-box").hide();

	$("#go").button();
	$("#back").button();

	$("#go").click(do_go);
	$("#back").click(show_search_box);
	
	// Load the slider
	$( "#slider-range" ).slider({
		range: true,
		min: 0,
		max: 9000,
		values: [ 0, 9000 ],
		step: 50,
		slide: function( event, ui ) {
			$( "#amount" ).val( "£" + ui.values[ 0 ] + " - £" + ui.values[ 1 ] );
		}
	});
	$( "#amount" ).val( "£" + $( "#slider-range" ).slider( "values", 0 ) +
		" - £" + $( "#slider-range" ).slider( "values", 1 ) );
		
	//$( "#results-sel" ).selectable();
});