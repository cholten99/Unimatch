<?php
	echo $_GET['sort'];
?>